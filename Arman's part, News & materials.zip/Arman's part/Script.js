//let city = prompt("Enter your city: ");
/*
$(document).ready(function(){
    $("select.select_city").change(function(){
        var selectedCountry = $(this).children("option:selected").val();
        alert("You have selected the country - " + selectedCountry);
    });
});
var cityy = "Lahore";
$.getJSON("http://api.openweathermap.org/data/2.5/weather?q=" + selectedCountry + "&units=metric&APPID=d89208ad904d31a4402384ff1d4d1a2f",

    function(data){
        console.log(data);

        var icon = "https://openweathermap.org/img/w/" + data.weather[0].icon + ".png";
        $('.icon').attr("src", icon);

        var temp = Math.round(data.main.temp);
        $('.temp').append(temp);

        var weather = data.weather[0].main;
        $('.weather').append(weather);

        var city = data.name;
        $('.city').append(city);
    });
*/
fetch('https://api.openweathermap.org/data/2.5/weather?q=astana&appid=5421f7f9b3793273eb9738868d3777f1&units=metric&lang=ru')//interface to work with query & answers http
 // fetch('https://api.openweathermap.org/data/2.5/weather?q=" + city + "&units=metric&APPID=d89208ad904d31a4402384ff1d4d1a2f')
        .then(function (resp){return resp.json()})
        .then(function (data){
                console.log(data);
                document.querySelector('.city').textContent = data.name; //selecting elements from html and querying the data
                //document.querySelector('.data-t').textContent = data.timezone;
                document.querySelector('.api-desc').textContent = data.weather.description;
                document.querySelector('.deg').textContent = data.main.temp;
                document.querySelector('.moisture2').textContent = data.main.humidity;
                document.querySelector('.country').textContent = data.sys.country;
                document.querySelector('.feelsLike').textContent = data.main.feels_like;
                document.querySelector('.rain-vol').textContent=data.clouds.all;
                //document.querySelector('.data-t').textContent =data.city.sun.rise;
               // document.querySelector('.last-up').textContent=data.lastupdate.value;


});